-- MariaDB dump 10.17  Distrib 10.4.8-MariaDB, for Linux (x86_64)
--
-- Host: 108.179.253.230    Database: flexib52_db_estoque
-- ------------------------------------------------------
-- Server version	5.6.41-84.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_agenda`
--

DROP TABLE IF EXISTS `tb_agenda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_agenda` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_emp` int(11) NOT NULL,
  `nome` varchar(40) NOT NULL,
  `email` varchar(70) DEFAULT NULL,
  `depart` varchar(15) DEFAULT NULL,
  `cel1` varchar(14) DEFAULT NULL,
  `cel2` varchar(14) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_emp` (`id_emp`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_agenda`
--

LOCK TABLES `tb_agenda` WRITE;
/*!40000 ALTER TABLE `tb_agenda` DISABLE KEYS */;
INSERT INTO `tb_agenda` VALUES (1,16,'Agnaldo ','agnaldo10tintas@gmail.com ','vendas ','(12)99854-5636',' '),(2,37,'Tales Cembraneli Dantas  ','tales@flexibus.com.br  ','Eng.  ','(12)99711-3793','  '),(4,37,'Tania Cristina Morgado','tania@flexibus.com.br','supervisÃ£o','(12)99799-1867',''),(5,37,'Bruno JosÃ© Mathias','comercial@flexibus.com.br','comercial','(12)99120-2360',''),(6,16,'Sales','salesmartins15@gmail.com','Comercial','(11)96113-1106',''),(7,21,'Aline','alyne@almeidasusinagens.com.br','Contas a Pagar','',''),(8,47,'Gelson','','Pintor','(12)99641-9308',''),(9,49,'AntÃ´nio','','Vendas','','(12)4647-8080');
/*!40000 ALTER TABLE `tb_agenda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_empresa`
--

DROP TABLE IF EXISTS `tb_empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_empresa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) NOT NULL,
  `cnpj` varchar(14) DEFAULT NULL,
  `ie` varchar(14) DEFAULT NULL,
  `endereco` varchar(60) DEFAULT NULL,
  `cidade` varchar(30) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL,
  `tipo` varchar(3) DEFAULT NULL,
  `tel` varchar(15) DEFAULT NULL,
  `cep` varchar(10) DEFAULT NULL,
  `bairro` varchar(60) DEFAULT NULL,
  `num` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_empresa`
--

LOCK TABLES `tb_empresa` WRITE;
/*!40000 ALTER TABLE `tb_empresa` DISABLE KEYS */;
INSERT INTO `tb_empresa` VALUES (16,'farben s/a industria quimica ','85111441000385','336564779116 ','av. amancio gaioli, 725 bairro agua chata ','guarulhos ','SC','FOR','(11)2088-9200 ','07.251-250',NULL,NULL),(13,'FLEXIBUS SANFONADOS ','00519547000106','  ','Rua dr. Rosalvo de Almeida Telles, 2070  ','Cacapava  ','SP','FOR','(12)3653-2230 ','12283-020 ',' ',' '),(15,'maxi rubber industria quimica ltda ','00283822000470','286391325110 ','av. luiz merenda, 659 ','diadema ','SP','FOR','(11)4092-7777 ','99.931-390',NULL,NULL),(18,'allfra comercial ltda ','17353313000126','796138627113 ','avenida torres tibagy ,690 -vila aprazivel  ','guarulhos ','SP','FOR','(11) 22033703 ','0706200 ',NULL,NULL),(19,'VANDERLEI RODRIGUES MANUTENCAO INDUSTRIAL ME   ','2465059900177 ','   ','RUA PRES. JUSCELINO KUBITSCHEK OLIVEIRA,122-JD MARIA CANDIDA','CAÃ‡APAVA  ','SP','FOR','3653-5643   ','12.284-280',' ',' '),(20,'OUTROS','','','','','SP','FOR','','',NULL,NULL),(21,'ALMEIDAS USINAGEM','','','','','SP','FOR','','',NULL,NULL),(22,'DORIVALE PAPELARIA','','','','','SP','FOR','','',NULL,NULL),(23,'IMPERIAL TINTAS','','','','','SP','FOR','','',NULL,NULL),(24,'ROCAR','','','','','SP','FOR','','',NULL,NULL),(25,'CASA DE FERRAGENS','','','','','SP','FOR','','',NULL,NULL),(26,'SURIANA','','','','','SP','FOR','','',NULL,NULL),(27,'SALES DISTRIBUIDORA','','','','','SP','FOR','','',NULL,NULL),(28,'QUARIS','','','','','SP','FOR','','',NULL,NULL),(29,'LG GRAMPIADORES','','','','','SP','FOR','','',NULL,NULL),(30,'REIS E REIS','','','','','SP','FOR','','',NULL,NULL),(31,'FCC ','','','','','SP','FOR','','',NULL,NULL),(32,'WS FROTAMIX','','','','','SP','FOR','','',NULL,NULL),(33,'BOSS BRASIL','','','','','SP','FOR','','',NULL,NULL),(34,'ABRAFIX PARAFUSO','','','','','SP','FOR','','',NULL,NULL),(35,'Linhasita','','','','','SP','FOR','','',NULL,NULL),(36,'Casa do parafuso','','','','','SP','FOR','','',NULL,NULL),(37,'FLEXIBUS SANFONADOS  ','00519547000106','234033845113  ','AV. DR. ROSALVO DE ALMEIDA TELLES,270 NOVA CPV  ','CaÃ‡apava  ','SP','CLI','12-36532230  ','12283-020 ','Nova CaÃ‡apava  ','2070 '),(38,'CISER PARAFUSO','','','','','SP','FOR','','',NULL,NULL),(39,'Liart','','','','','SP','FOR','','',NULL,NULL),(40,'VINIFLEX','','','','','SP','FOR','','',NULL,NULL),(41,'bandeirantes quimica','','','','','SP','FOR','','',NULL,NULL),(42,'MOBIBRASIL TRANSPORTE SAO PAULO LTDA      ','11031202000117','      ','ESTRADA DO ALVARENGA      ','SÃƒo Paulo    ','SP','CLI','      ','04474-340 ','A-BALNEARIO SAO FRANCISCO   ','4000 '),(43,'Empresa de Transporte SÃ£o Judas Tadeu      ','84302504000156','0100068400167 ','Rodovia BR 364, KM 05     ','rio branco       ','AC','CLI',' 75 8315-2262 ','69.920-223','Distrito industrial   ','8317 '),(45,'TRANSPORTADORA TURÃSTICA SUZANO LTDA','52406329000665','626879237113','AV. QUEIROS DOS SANTOS, 786 -CENTRO','SANTO ANDRÃ‰','SP','CLI','1144273337','09015310',NULL,NULL),(46,'METRA SISTEMA METROPOLITANO TRANSP. LTDA.   ','01764417000193','635317450113  ','RUA JOAQUIM CASEMIRO ','SÃ£o Bernardo do Campo   ','SP','CLI','1143903850   ','09880-050 ','  planalto   ','  290'),(47,'mineraCAo paraiba ltda   ','58707316000106',' 234020628118 ',' rua marajoara    ','CaÃ§apava ','SP','CLI','12 99112-1273 ',' 12.282570','jardim campo grande   ',' s/n '),(48,'ViaCAo Jacarei Ltda     ','50479476000125','645140864117  ','Rod Presidente Dutra    ','SÃ£o JosÃ© dos Campos  ','SP','CLI','(12) 3931-3966','12240420  ','    limoeiro ','156  '),(49,'Macro AlumÃ­nio','','','','SÃ£o Paulo','SP','FOR','','',NULL,NULL),(50,'VIAÃ‡ÃƒO METRÃ“POLE PAULISTA S/A ','31974104000392',' ','AV. ÃGUIA DE HAIA,  ','SÃ£o Paulo ','SP','CLI','11-2026-9220 ','03694-000 ','CIDADE AE CARVALHO ','2970 ');
/*!40000 ALTER TABLE `tb_empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_entrada`
--

DROP TABLE IF EXISTS `tb_entrada`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_entrada` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nf` varchar(10) DEFAULT NULL,
  `id_emp` int(11) NOT NULL,
  `data_ent` date DEFAULT NULL,
  `resp` varchar(15) DEFAULT NULL,
  `status` varchar(7) NOT NULL DEFAULT 'ABERTO',
  PRIMARY KEY (`id`),
  KEY `id_emp` (`id_emp`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_entrada`
--

LOCK TABLES `tb_entrada` WRITE;
/*!40000 ALTER TABLE `tb_entrada` DISABLE KEYS */;
INSERT INTO `tb_entrada` VALUES (16,'ALMEIDAS',21,'2019-12-04','tania','FECHADO'),(15,'FABRICACAO',13,'2019-12-03','tania','FECHADO'),(17,'171677',16,'2019-12-05','tania','FECHADO'),(13,'170966',16,'2019-11-25','tania','FECHADO'),(12,'FABRICACAO',13,'2019-11-27','tania','FECHADO'),(9,'fab.',13,'2019-11-22','tania','FECHADO'),(18,'171865',16,'2019-12-07','tania','FECHADO'),(19,'FABRICACAO',13,'2019-12-10','tania','FECHADO'),(20,'FABRICACAO',13,'2019-12-18','tania','FECHADO'),(21,'42554',15,'2019-12-16','tania','FECHADO'),(22,'172730',16,'2019-12-19','tania','FECHADO');
/*!40000 ALTER TABLE `tb_entrada` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_item_compra`
--

DROP TABLE IF EXISTS `tb_item_compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_item_compra` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_prod` int(11) NOT NULL,
  `id_ent` int(11) DEFAULT NULL,
  `qtd` double NOT NULL DEFAULT '0',
  `preco` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id_prod` (`id_prod`),
  KEY `id_ent` (`id_ent`)
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_item_compra`
--

LOCK TABLES `tb_item_compra` WRITE;
/*!40000 ALTER TABLE `tb_item_compra` DISABLE KEYS */;
INSERT INTO `tb_item_compra` VALUES (30,144,19,4,517),(25,145,16,4,600),(24,149,15,20,200),(23,141,15,6,920),(22,90,13,3,91.04),(21,142,12,155,80),(27,31,18,12,41.46),(26,110,17,2,49.67),(20,141,12,2,920),(18,141,9,2,920),(28,94,18,12,96.67),(15,142,9,80,100),(29,112,18,3,94.68),(31,148,19,120,80),(35,144,20,5,517),(34,145,19,10,600),(36,218,21,8,40.16),(37,35,21,6,27.61),(38,227,21,48,9.1),(39,43,21,6,12.49),(40,46,21,6,13.83),(41,47,21,6,14.7),(42,228,21,12,8.89),(43,229,21,12,9.5),(44,230,21,6,56.53),(45,53,21,12,9.95),(46,58,21,12,6.03),(47,59,21,6,7.08),(48,231,21,15,6.22),(49,232,21,15,6.22),(50,69,22,60,4.13),(51,31,22,24,41.46),(52,110,22,2,49.67),(53,111,22,2,216.12),(54,117,22,2,49.29),(55,120,22,2,203.35),(56,125,22,2,87.69);
/*!40000 ALTER TABLE `tb_item_compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_item_ped`
--

DROP TABLE IF EXISTS `tb_item_ped`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_item_ped` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_prod` int(11) NOT NULL,
  `id_ped` int(11) DEFAULT NULL,
  `qtd` double NOT NULL DEFAULT '0',
  `preco` double NOT NULL DEFAULT '0',
  `und` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_prod` (`id_prod`),
  KEY `id_ped` (`id_ped`)
) ENGINE=MyISAM AUTO_INCREMENT=294 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_item_ped`
--

LOCK TABLES `tb_item_ped` WRITE;
/*!40000 ALTER TABLE `tb_item_ped` DISABLE KEYS */;
INSERT INTO `tb_item_ped` VALUES (59,142,13,80,100,NULL),(58,148,13,40,80,NULL),(57,141,13,2,920,NULL),(56,153,13,1,13.85,NULL),(55,165,13,3,1.98,NULL),(54,169,13,1,55.15,NULL),(53,168,13,1,166.88,NULL),(52,166,13,7,0.6,NULL),(51,167,13,2,1.2,NULL),(50,153,13,1,13.85,NULL),(127,149,32,15,200,NULL),(49,158,13,1,4,NULL),(48,156,13,2,1.9,NULL),(47,160,13,1,12,NULL),(125,153,32,6,13.85,NULL),(124,156,32,6,1.9,NULL),(123,166,32,5,0.6,NULL),(122,167,32,3,1.2,NULL),(60,170,13,300,0.05,NULL),(121,170,32,500,0.05,NULL),(120,31,31,2,58.03,NULL),(119,31,30,2,58.03,NULL),(118,31,29,1,58.03,NULL),(117,32,29,2,48.5925,NULL),(116,53,29,1,13.93,NULL),(115,10,29,2,4.802,NULL),(114,206,29,1,201.68,NULL),(113,13,27,2,7.882,NULL),(112,28,27,1,60.852,NULL),(111,32,27,2,48.5925,NULL),(110,204,27,1,121.62,NULL),(109,29,26,1,11.452,NULL),(108,147,26,20,1.2,NULL),(107,141,26,1,920,NULL),(106,186,26,1,3000,NULL),(105,148,26,20,80,NULL),(104,156,26,2,1.9,NULL),(103,153,26,3,13.85,NULL),(102,150,25,2,150,NULL),(101,139,24,2,750,NULL),(100,145,24,3,600,NULL),(99,201,23,1,3000,NULL),(98,144,22,2,517,NULL),(94,141,18,6,920,NULL),(93,150,16,2,150,NULL),(128,144,32,1,517,NULL),(129,190,32,1,32,NULL),(130,176,32,200,0.05,NULL),(131,177,32,50,0.0825,NULL),(132,174,32,200,0.05,NULL),(133,141,32,3,920,NULL),(134,148,32,40,80,NULL),(135,32,32,2,48.5925,NULL),(136,184,32,1,2000,NULL),(137,21,32,3,1.792,NULL),(138,110,32,1,81.9555,NULL),(139,160,32,1,12,NULL),(140,145,33,2,600,NULL),(141,142,18,10,70,NULL),(143,18,34,20,1.792,NULL),(144,58,34,1,8.442,NULL),(145,46,34,1,19.362,NULL),(146,13,34,2,7.882,NULL),(147,12,34,2,3.948,NULL),(148,207,34,1,306.89,NULL),(150,11,35,15,3.16,NULL),(151,13,35,15,7.88,NULL),(152,31,35,5,58.03,NULL),(153,208,35,1,62.06,NULL),(154,209,35,2,51.085,NULL),(155,210,36,1,34.596,NULL),(156,181,37,24,0.5,NULL),(157,164,37,8,3,NULL),(158,197,37,1,8,NULL),(159,151,37,8,45,NULL),(160,191,37,1,5,NULL),(161,158,37,2,4,NULL),(162,153,37,1,13.85,NULL),(163,179,37,1,35,NULL),(164,178,37,435,0.05,NULL),(165,156,37,2,1.9,NULL),(166,27,37,1,208.1475,NULL),(167,153,39,2,13.85,NULL),(168,156,39,2,1.9,NULL),(169,152,39,1,15,NULL),(170,68,39,1,76.3125,NULL),(171,32,39,1,48.5925,NULL),(172,17,39,1,1.792,NULL),(173,19,39,1,1.792,NULL),(174,20,39,1,1.792,NULL),(175,21,39,1,1.792,NULL),(176,21,39,1,1.792,NULL),(177,25,39,1,1.792,NULL),(178,22,39,1,1.792,NULL),(179,23,39,1,1.792,NULL),(180,190,39,1,32,NULL),(181,191,39,1,5,NULL),(182,156,39,1,1.9,NULL),(183,153,39,1,13.85,NULL),(184,170,39,100,0.05,NULL),(185,167,39,2,1.2,NULL),(186,167,39,2,1.2,NULL),(187,166,39,4,0.6,NULL),(201,17,41,20,1.792,'UNID\r\n '),(292,236,58,2,51.969,'900ml'),(293,29,59,3,13.497,'LATA\r\n '),(202,18,41,20,1.792,'UNID\r\n '),(203,20,41,30,1.792,'UNID\r\n '),(204,25,41,30,1.792,'UNID\r\n '),(205,32,41,5,48.5925,'LATA\r\n '),(206,31,41,1,58.044,'GALAO\r\n '),(223,21,41,30,1.792,'UNID\r\n '),(208,218,41,1,59.5332,'LATA\r\n '),(209,215,41,1,8.82,'LATA\r\n'),(210,13,41,3,7.882,'ROLO\r\n '),(211,11,41,3,3.7935,'ROLO\r\n '),(212,53,41,1,15.92,'LATA\r\n '),(213,14,41,10,0.77,'UNID\r\n '),(214,43,41,2,19.984,'LATA\r\n '),(215,59,41,2,11.328,'LATA\r\n '),(216,58,41,1,9.648,'LATA\r\n '),(222,46,41,1,22.128,'LATA\r\n '),(218,28,41,1,60.852,'LATA\r\n '),(219,220,41,2,251.6,'3.6L'),(220,220,41,1,62.9,'900ml'),(221,221,41,1,64.3245,'900ml'),(224,214,41,1,15.375,'LATA\r\n'),(225,219,41,1,5.6,'PECA\r\n'),(226,13,42,3,7.882,'ROLO\r\n '),(227,32,42,1,48.5925,'LATA\r\n '),(228,221,43,1,64.3245,'LATA\r\n '),(229,209,44,6,51.085,'900ml'),(232,0,40,1,204.34,NULL),(262,170,47,100,0.05,'PECA\r\n '),(261,144,46,4,517,'PECA\r\n'),(260,36,45,1,30,'LATA\r\n '),(256,209,40,5,204.34,'3.6L'),(257,32,45,1,48.5925,'LATA\r\n '),(258,28,45,1,60.852,'LATA\r\n '),(259,10,45,1,4.802,'PACOTE\r\n '),(290,220,55,1,31.45,'450ml'),(291,237,57,1,24.9185,'450ml'),(263,13,47,1,7.882,'ROLO\r\n '),(264,28,47,1,60.852,'LATA\r\n '),(265,147,47,15,1.2,'PECA\r\n '),(266,161,47,1,12,'CAIXA\r\n '),(267,225,48,10,53.159,'900ml'),(268,31,48,18,58.03,'GALAO\r\n '),(269,206,49,1,25.20375,'450ml'),(273,29,49,3,13.497,'LATA\r\n '),(272,10,49,1,4.802,'PACOTE\r\n '),(274,213,49,1,29.624,'LATA\r\n'),(275,32,49,1,48.5925,'LATA\r\n '),(276,206,49,2,50.4075,'900ml'),(277,143,50,20,57.5,'PECA\r\n '),(278,29,51,2,13.497,'LATA\r\n '),(279,32,51,2,48.5925,'LATA\r\n '),(280,7,52,1,10.01,'ROLO\r\n '),(281,214,52,1,15.375,'LATA\r\n'),(282,215,52,1,8.82,'LATA\r\n '),(283,31,52,1,58.044,'GALAO\r\n '),(284,234,52,1,29.88,'UNID\r\n '),(288,225,53,15,53.159,'900ml'),(287,235,52,1,19.08,'LATA\r\n'),(289,232,54,2,8.2,'LATA\r\n');
/*!40000 ALTER TABLE `tb_item_ped` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_pedido`
--

DROP TABLE IF EXISTS `tb_pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_pedido` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_emp` int(11) NOT NULL,
  `data_ped` date DEFAULT NULL,
  `data_ent` date DEFAULT NULL,
  `resp` varchar(15) DEFAULT NULL,
  `comp` varchar(30) DEFAULT NULL,
  `num_ped` varchar(15) DEFAULT NULL,
  `status` varchar(7) NOT NULL DEFAULT 'ABERTO',
  `nf` varchar(10) DEFAULT NULL,
  `desconto` double NOT NULL DEFAULT '0',
  `cond_pgto` varchar(100) DEFAULT '28 d.d.d',
  `obs` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_emp` (`id_emp`)
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_pedido`
--

LOCK TABLES `tb_pedido` WRITE;
/*!40000 ALTER TABLE `tb_pedido` DISABLE KEYS */;
INSERT INTO `tb_pedido` VALUES (13,37,'2019-11-22','2019-11-22','TANIA ','TANIA ','191122-0 ','FECHADO',NULL,0,'28 d. ',' '),(16,42,'2019-11-22','0000-00-00','TANIA     ','ALISSON     ','5729184     ','FECHADO',NULL,0,'28 ddd ','(fob) '),(18,43,'2019-11-22','0000-00-00','tania ','marcos ','191122-2 ','FECHADO',NULL,0,'28 d.d.d ','frete fob '),(22,45,'2019-11-27','0000-00-00','TANIA','EDEVALDO','191127-1','FECHADO',NULL,0,'28 d.d.d',NULL),(23,46,'2019-11-27','0000-00-00','tania     ','DENIS     ','191127-2     ','FECHADO',NULL,0,'30 DIAS ','SERV. REALIZADO NA FLEXIBUS.     '),(24,42,'2019-11-27','2019-11-28','tania','ALISSON','5729496','FECHADO',NULL,0,'28 d.d.d',NULL),(25,42,'2019-11-27','2019-11-28','tania ','ALISSON ','5729184 ','FECHADO',NULL,0,'28 d.d.d ',' '),(26,37,'2019-11-27','0000-00-00','tania  ','TANIA  ','191127-3  ','FECHADO',NULL,0,'28 d.d.d  ',' USO INTERNO '),(27,47,'2019-11-29','2019-11-29','tania','CRISTINA','191129-1','FECHADO',NULL,0,'28 d.d.d',NULL),(39,37,'2019-12-10','2019-12-10','tania','USO INTERNO','191210-1','FECHADO',NULL,0,'28 d.d.d',NULL),(29,47,'2019-12-03','2019-12-03','tania ','cristina ','191203-1 ','FECHADO',NULL,0,'28 d.d.d ',' '),(30,14,'2019-12-03','2019-12-04','tania','rodrigo','191203-2','ABERTO',NULL,0,'28 d.d.d',NULL),(31,48,'2019-12-03','2019-12-04','tania ','rodrigo ','191203-3 ','FECHADO',NULL,0,'28 d.d.d ',' '),(32,37,'2019-12-04','2019-12-04','tania','saida est.','191204-1','FECHADO',NULL,0,'28 d.d.d',NULL),(33,42,'2019-12-02','2019-12-04','tania ','ALISSON ','5730312 ','FECHADO',NULL,0,'28 d.d.d ',' '),(34,47,'2019-12-05','2019-12-05','tania ','CRISTINA ','191205-1 ','FECHADO',NULL,0,'28 d.d.d ','SOLICITADO PELO SR. GELSON '),(35,48,'2019-12-06','2019-12-06','tania ','rodrigo ','204801 ','FECHADO',NULL,0,'28 d.d.d ','pedido 204806 e 204801 '),(36,47,'2019-12-06','2019-12-06','tania','CRISTINA','191206-1','FECHADO',NULL,0,'28 d.d.d',NULL),(37,37,'2019-12-06','2019-12-06','tales','','191206-2','FECHADO',NULL,0,'28 d.d.d',NULL),(40,37,'2019-12-11','2019-12-12','tales        ','n      ','191211-1       ','ABERTO',NULL,0,'28 d.d.d        ','        '),(41,47,'2019-12-11','2019-12-11','tania ','CRISTINA ','191211-2 ','FECHADO',NULL,0,'28 d.d.d ','SOLICITADO PELO SR. GELSON '),(42,47,'2019-11-18','2019-11-18','tania ','Cristina ','191118-0 ','FECHADO',NULL,0,'28 d.d.d ','SOLICITADO PELO SR. GELSON '),(43,47,'2019-12-13','2019-12-13','tania','CRISTINA','191213-1','FECHADO',NULL,0,'28 d.d.d',NULL),(44,48,'2019-12-13','2019-12-13','tania','rodrigo','191213-2','FECHADO',NULL,0,'28 d.d.d',NULL),(45,47,'2019-12-17','2019-12-17','tania','CRISTINA','191217-1','FECHADO',NULL,0,'28 d.d.d',NULL),(46,42,'2019-12-17','2019-12-17','tania','ALISSON','5731779','FECHADO',NULL,0,'28 d.d.d',NULL),(47,37,'2019-12-18','2019-12-18','tania','USO INTERNO','191218-1','FECHADO',NULL,0,'28 d.d.d',NULL),(48,48,'2019-12-19','2019-12-19','tania','rodrigo','0205074','FECHADO',NULL,0,'28 d.d.d',NULL),(49,47,'2019-12-19','2019-12-19','tania','CRISTINA','191219-1','FECHADO',NULL,0,'28 d.d.d',NULL),(50,50,'2019-12-19','0000-00-00','tania ','paraiba ','191219-2 ','FECHADO',NULL,0,'28 d.d.d ',' '),(51,47,'2019-12-20','2019-12-20','Tales   ','CRISTINA ','191220-1   ','FECHADO',NULL,0,'28 d.d.d   ','SOLICITADO PELO SR. GELSON  '),(52,47,'2019-12-23','2019-12-23','tania','CRISTINA','191223-1','FECHADO',NULL,0,'28 d.d.d',NULL),(53,48,'2019-12-23','2019-12-23','tania','rodrigo','0205143','FECHADO',NULL,0,'28 d.d.d',NULL),(54,48,'2019-12-23','2019-12-23','tania','rodrigo','204891','FECHADO',NULL,0,'28 d.d.d',NULL),(55,37,'2019-12-26','2019-12-26','tania','CRISTINA','191226-1','ABERTO',NULL,0,'28 d.d.d',NULL),(58,48,'2019-12-26','2019-12-27','tales  ','Rodrigo  ','191226-3  ','FECHADO',NULL,0,'28 d.d.d  ','  '),(57,37,'2019-12-26','2019-12-26','tania','CRISTINA','191226-2','ABERTO',NULL,0,'28 d.d.d',NULL),(59,37,'2019-12-27','2019-12-27','tania','CRISTINA','191227-1','ABERTO',NULL,0,'28 d.d.d',NULL);
/*!40000 ALTER TABLE `tb_pedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_produto`
--

DROP TABLE IF EXISTS `tb_produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_produto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_emp` int(11) NOT NULL,
  `descricao` varchar(80) NOT NULL,
  `estoque` double NOT NULL DEFAULT '0',
  `etq_min` double NOT NULL DEFAULT '0',
  `unidade` varchar(10) DEFAULT NULL,
  `ncm` varchar(8) DEFAULT NULL,
  `cod` int(11) DEFAULT NULL,
  `cod_bar` varchar(15) DEFAULT NULL,
  `reserva` double NOT NULL DEFAULT '0',
  `preco_comp` double NOT NULL DEFAULT '0',
  `margem` double NOT NULL DEFAULT '40',
  `tipo` varchar(7) DEFAULT 'VENDA',
  PRIMARY KEY (`id`),
  UNIQUE KEY `cod` (`cod`),
  KEY `id_emp` (`id_emp`)
) ENGINE=MyISAM AUTO_INCREMENT=253 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_produto`
--

LOCK TABLES `tb_produto` WRITE;
/*!40000 ALTER TABLE `tb_produto` DISABLE KEYS */;
INSERT INTO `tb_produto` VALUES (25,18,'DISCO DE LIXA P 320   ',119,4,'UNID\r\n ','68051000',1077,'063     ',0,1.28,40,'VENDA '),(4,0,'',0,0,'','',0,'',0,0,40,'VENDA'),(7,18,'PAPEL SEMI KRAFT 60GRS 45CM D10 1,5KG      ',29,10,'ROLO\r\n ','48025592',1062,'008      ',0,7.15,40,'VENDA '),(8,18,'PAPEL SEMI KRAFT 60GRS 90CM D10 3KG         ',20,10,'ROLO\r\n ','48025592',1063,'009         ',0,13.94,40,'VENDA '),(9,18,'ESPATULA FLEXIVEL PARA APLICACAO DE MASSAS   ',30,10,'PECA\r\n ','82055900',1064,'085   ',0,1.18,40,'VENDA'),(10,18,'ESTOPA PARA POLIMENTO ALLFRA 400G 100% ALGODÃƒO  ',116,40,'PACOTE\r\n ','52029900',1065,'251  ',0,3.43,40,'VENDA'),(11,18,'FITA CREPE AUTOMOTIVA AMARELA 18X40 -adere   ',46,30,'ROLO\r\n ','48114110',1066,'305     ',0,2.81,35,'VENDA '),(12,18,'FITA CREPE USO GERAL BRANCA 24X50 ',58,30,'ROLO\r\n ','48114110',1067,'307   ',0,2.82,40,'VENDA'),(13,18,'FITA CREPE USO GERAL BRANCA 48X50- ADERE ',46,30,'ROLO\r\n ','48114110',1068,'306   ',0,5.63,40,'VENDA'),(14,18,'COADOR DESCARTAVEL   ',290,50,'UNID\r\n ','96040000',1069,'086   ',0,0.55,40,'VENDA'),(15,18,'SUPORTE PARA LIXADEIRA ROTO ORBITAL HOOKIT 6  ',5,5,'UNID\r\n ','84669200',1070,'057  ',0,25.97,40,'VENDA'),(16,18,'SUPORTE PARA LIXADEIRA ROTO ORBITAL HOOKIT 5Â´   ',5,5,'UNID\r\n ','84669200',1071,'058   ',0,24.5,40,'VENDA'),(17,18,'DISCO DE LIXA P40   ',79,50,'UNID\r\n ','68051000',1072,'059     ',0,1.28,40,'VENDA '),(18,18,'DISCO DE LIXA P80   ',160,4,'UNID\r\n ','68051000',1073,'060      ',0,1.28,40,'VENDA '),(19,18,'DISCO DE LIXA P120   ',99,50,'UNID\r\n ','68051000',1074,'214     ',0,1.28,40,'VENDA '),(20,18,'DISCO DE LIXA P150   ',69,50,'UNID\r\n ','68051000',1075,'061      ',0,1.28,40,'VENDA '),(21,18,'DISCO DE LIXA P220 ',165,50,'UNID\r\n ','68051000',1076,'062        ',0,1.28,40,'VENDA '),(22,18,'DISCO DE LIXA P600   ',24,10,'UNID\r\n ','68051000',1078,'065    ',0,1.28,40,'VENDA '),(23,18,'DISCO DE LIXA P800   ',24,25,'UNID\r\n ','68051000',1079,'066     ',0,1.28,40,'VENDA '),(24,18,'ALL LUB ANTI CORROSIVO COLORART     ',20,10,'LATA\r\n ','38249941',1080,'275     ',0,5.25,20,'VENDA'),(27,16,'thinner 5000 -18 lt       ',3,4,'GALAO\r\n ','38140090',1081,'555.000-018    ',0,126.15,65,'VENDA '),(28,16,'thinner 5000 -5 lt  ',4,5,'LATA\r\n ','38140090',1082,'555.000-5.0   ',0,36.88,65,'VENDA'),(29,16,'THINNER PU 8000 -900 ml ',54,30,'LATA\r\n ','38140090',1083,'558.000-0.9 ',0,8.18,65,'VENDA'),(30,16,'THINNER PU 8000 - 18 lt      ',2,5,'LATA\r\n ','38140090',1084,'558.000-018    ',0,145.23,65,'VENDA '),(31,16,'THINNER PU 8000 -5 lt     ',23,5,'GALAO\r\n ','38140090',1085,'558.000-5.0    ',0,41.46,40,'VENDA '),(32,16,'catalisador P/ ESM.PU ACR.-900 ml    ',48,50,'LATA\r\n ','38249931',1086,'573.790-0.9    ',0,29.45,65,'VENDA '),(34,15,'MASSA DE POLIESTER 750G ',12,20,'LATA\r\n ','32141010',1088,'1MG018 ',2,14.37,60,'VENDA'),(35,15,'MASSA DE POLIESTER 1,5 KG ',18,20,'LATA\r\n ','32141010',1089,'1MG024 ',0,27.61,60,'VENDA'),(36,15,'MASSA DE POLIESTER 1KG ',11,15,'LATA\r\n ','32141010',1090,'1MG028 ',0,18.75,60,'VENDA'),(37,15,'MASSA DE POLIESTER C/ FIBRA- 750 g -c/ catalisador  ',12,20,'LATA\r\n ','32141010',1091,'1MG051  ',0,21.06,60,'VENDA '),(38,15,'MASSA RaPIDA CINZA 1,25 KG  ',12,15,'LATA\r\n ','32141020',1092,'2MA001  ',0,17.18,60,'VENDA'),(39,15,'MASSA RaPIDA PREMIUM-620 G  ',12,12,'LATA\r\n ','32141020',1093,'2MA006  ',0,11.01,60,'VENDA'),(40,15,'PRIMER UNIVERSAL -900 ml ',12,15,'LATA\r\n ','32089010',1094,'2MA015  ',0,15.92,60,'VENDA'),(41,15,'MASSA RaPIDA BRANCA 1,25 KG  ',12,15,'LATA\r\n ','32141020',1095,'2MA085  ',0,18.51,60,'VENDA'),(42,15,'PRIMER HS PU 411-900 ml ',6,10,'LATA\r\n ','32081010',1096,'2MG002 ',0,14.49,60,'VENDA'),(43,15,'PRIMER HS 511- 750 ml ',10,6,'LATA\r\n ','32081010',1097,'2MG010 ',1,12.49,60,'VENDA'),(44,15,'PRIMER HS PU 611 PRETO -900 ml ',6,10,'LATA\r\n ','32081010',1098,'2MG015 ',0,18.57,60,'VENDA'),(45,15,'REMOVEDOR PASTOSO 1,0 KG ',12,12,'LATA\r\n ','38140090',1099,'2MS001 ',0,16.06,60,'VENDA'),(46,15,'WASH PRIMER - 600ML  ',10,10,'LATA\r\n ','32082019',1100,'3MA001  ',0,13.83,60,'VENDA '),(47,15,'PRETO FOSCO VINILICO - 600ML ',12,6,'LATA\r\n ','32082019',1101,'3MA011 ',0,14.7,60,'VENDA'),(48,15,'SELADORA PARA PLASTICO -900ML ',6,6,'LATA\r\n ','32089039',1102,'4MP006 ',0,22.61,60,'VENDA'),(50,15,'MASSA DE POLIR 1 - 980 G ',12,15,'LATA\r\n ','34053000',1103,'6mh001 ',0,16.77,60,'VENDA'),(51,15,'MASSA DE POLIR 2 - 970 G ',12,12,'LATA\r\n ','34053000',1104,'6mh010 ',0,16.92,60,'VENDA'),(52,15,'COLA UNIVERSAL -774 G ',12,15,'LATA\r\n ','35069110',1105,'7ma061 ',0,18.19,60,'VENDA'),(53,15,'SOLUCAO DESENGRAXANTE- 900ML  ',22,20,'LATA\r\n ','29012900',1106,'7MP012  ',0,9.95,60,'VENDA'),(54,15,'MAXI MANTA 1,40 X 0,50 M ',12,12,'PECA\r\n ','70193100',1107,'8MP046 ',0,9.57,60,'VENDA'),(55,15,'MAXI BOINA DUPLA FACE BRANCA  ',4,4,'PECA\r\n ','9603500 ',1108,'8MP048  ',0,75.9,60,'VENDA'),(56,15,'MAXI BOINA DUPLA FACE AMARELA  ',4,4,'PECA\r\n ','9603500 ',1109,'8MP050  ',0,75.9,60,'VENDA'),(57,15,'PANO POLIMENTO MICRO FIBRA    ',12,12,'UNID\r\n ','63071000',1110,'8MP056    ',0,8.74,60,'VENDA'),(58,15,'CATALISADOR . WASH/PRETO FOSCO -300 ML ',22,12,'LATA\r\n ','38249939',1111,'9MB009 ',0,6.03,60,'VENDA'),(59,15,'CATALISADOR  PRIMER PU 511 -150 ML ',10,6,'LATA\r\n ','38249931',1112,'9MB021 ',0,7.08,60,'VENDA'),(60,15,'CATALISADOR  PRIMER PU 411 -225 ML ',6,6,'LATA\r\n ','38249931',1113,'9MB022 ',0,11.15,60,'VENDA'),(61,15,'CATALISADOR  PRIME PU 611 -150 ML ',6,6,'LATA\r\n ','38249931',1114,'9MB037 ',0,9.03,60,'VENDA'),(68,16,'solucao flexibilizante-900 ml ',5,12,'LATA\r\n ','32081010',1117,'509.080-0.9 ',0,46.25,65,'VENDA'),(69,16,'lata 900 ml linha frota - vasilhame ',172,100,'LATA\r\n ','73102190',1115,'005.144 ',0,4.13,65,'VENDA'),(70,16,'galao linha frota tintometrica- 3,6 ml-vasilhame ',60,100,'LATA\r\n ','73102990',1116,'0005.184 ',0,10.58,65,'VENDA'),(72,16,'conc.violeta rl- pigmento 900 ml    ',2,2,'LATA\r\n ','32129090',1118,'ac135-0.9    ',0,113.62,0,'PIGMTO '),(73,16,'conc.vermelho vivo-pigmento -900 ml  ',2,2,'LATA\r\n ','32129090',1119,'ac135-0.9  ',0,70.51,0,'PIGMTO'),(74,16,'conc.alquidico branco- pigmento -3.6 ml  ',1,1,'PECA\r\n ','32129090',1120,'ac171-3.6  ',0,142.56,0,'PIGMTO'),(75,16,'conc.amarelo ouro-pigmento -900 ml   ',1,1,'LATA\r\n ','32129090',1121,'ac172-9.0   ',0,55.78,0,'PIGMTO'),(76,16,'conc.amarelo limÃ£o - pigmento 900 ml  ',1,1,'LATA\r\n ','32129090',1122,'ac173-9.0  ',0,52.76,0,'PIGMTO'),(77,16,'conc.amarelo oxido-pigmento-900 ml  ',1,1,'LATA\r\n ','32129090',1123,'ac174-0.9  ',0,31.08,0,'PIGMTO'),(78,16,'conc.laranja-pigmento -900 ml  ',1,1,'LATA\r\n ','32129090',1124,'ac175-0.9  ',0,100.88,0,'PIGMTO'),(79,16,'conc.vermelho oxido-pigmento 900 ml  ',1,1,'LATA\r\n ','32129090',1125,'ac176-0.9  ',0,34.67,0,'PIGMTO'),(80,16,'conc.azul-pigmento 900 ml  ',1,1,'LATA\r\n ','32129090',1126,'ac177-0.9  ',0,42.6,0,'PIGMTO'),(81,16,'conc. verde- pigmento 900 ml  ',1,1,'LATA\r\n ','32129090',1127,'ac178-0.9  ',0,43.29,0,'PIGMTO'),(82,16,'conc.vermelho pleno -pigmento 900 ml  ',1,1,'LATA\r\n ','32129090',1128,'ac179-0.9  ',0,45.6,0,'PIGMTO'),(167,27,'SABAO EM PEDRA',75,30,'UNID\r\n','00000000',176,'176',0,1.2,0,'VENDA'),(83,16,'conc.preto-pigmento 900 ml  ',2,1,'LATA\r\n ','32129090',1129,'ac180-0.9  ',0,26.39,0,'PIGMTO'),(85,16,'conc.amarelo limÃ£o organico-pigmento 900 ml   ',1,1,'LATA\r\n ','32129090',1130,'ac183-0.9   ',0,63.36,0,'PIGMTO'),(86,16,'conc. laranja organico -pigmento 900 ml   ',1,1,'LATA\r\n ','32129090',1131,'ac185-0.9   ',0,62.18,0,'PIGMTO'),(87,16,'conc.vinho oxido-pigmento 900 ml  ',1,1,'LATA\r\n ','32129090',1132,'ac186-0.9  ',0,57.41,0,'PIGMTO'),(88,16,'conc.vermelho avioletado-pigmento 900 ml  ',1,1,'LATA\r\n ','32129090',1133,'ac279-0.9  ',0,122.31,0,'PIGMTO'),(89,16,'CONC.preto azulado-pigmento 900 ml  ',2,1,'LATA\r\n ','32129090',1134,'AC280-0.9  ',0,65.36,0,'PIGMTO'),(90,16,'base sint.branco -PIGMENTO 3.6 ml    ',0,8,'GALAO\r\n ','32081010',1135,'aes40-3.6    ',0,91.04,0,'PIGMTO '),(91,16,'clear sint.-PIGMENTO 3.6 ML ',8,5,'PECA\r\n ','32081020',1136,'AES45-3.6 ',0,63.41,0,'PIGMTO'),(92,16,'base nc branca automotiva- pigmento 3.6 ml ',8,8,'PECA\r\n ','32089021',1137,'anc55-3.6 ',0,104.99,0,'PIGMTO'),(93,16,'clear nc automotivo-pigmento 3.6 ml ',8,8,'PECA\r\n ','32089021',1138,'anc55-3.6 ',0,91.07,0,'PIGMTO'),(94,16,'base pu acr.incolor- pigmento 3.6 ml  ',21,12,'GALAO\r\n ','32081020',1139,'apa85-3.6  ',0,96.67,0,'PIGMTO '),(95,16,'base  poliester incolor-pigmento 18 lt ',1,1,'GALAO\r\n ','32081020',1140,'ape75-018 ',0,302.41,0,'PIGMTO'),(96,16,'base pu branca frota-pigmento 3.6 ml ',8,8,'GALAO\r\n ','32081010',1141,'apu60-3.6 ',0,125.11,0,'PIGMTO'),(168,32,'TINTA CINZA PARA SANFONA -3.6 ML',3,5,'GALAO\r\n','32081010',183,'183',0,166.88,0,'VENDA'),(97,16,'clear pu frota- PIGMENTO 3.6 ML ',8,8,'GALAO\r\n ','32081020',1142,'APU65-3.6 ',0,102.97,0,'PIGMTO'),(98,16,'CONC. UNIVERSAL VIOLETA-PIGMENTO 900 ML',1,1,'LATA\r\n','21129090',1143,'UC221-0.9',0,131.31,0,'PIGMTO'),(99,16,'CONC. AMARELO ALARANJADO UNIVERSAL- PIGMENTO 900 ML',1,1,'LATA\r\n','32129090',1144,'UC262-0.9',0,271.01,0,'PIGMTO'),(100,16,'CONC. UNIVERSAL CASTANHO TRANSP.-PIGMENTO 900 ML',1,1,'LATA\r\n','32129090',1145,'UC266-0.9',0,161.28,0,'PIGMTO'),(101,16,'CONC. UNIVERSAL VERMELHO SCARLAT TRANSP. -PIGMENTO 900 ML',1,1,'LATA\r\n','32129090',1146,'UC268-0.9',0,248.75,0,'PIGMTO'),(102,16,'CONC. UNIVERSAL PRETO INTENSO-PIGMENTO 900 ML',1,1,'LATA\r\n','32129090',1147,'UC270-0.9',0,59.52,0,'PIGMTO'),(103,16,'CONC. UNIVERSAL BRANCO TRANSP.- PIGMENTO 900 ML',1,1,'LATA\r\n','32129090',1148,'UC271-0.9',0,373.41,0,'PIGMTO'),(104,16,'CONC. UNIVERSAL VERMELHO AZULADO-PIGMENTO 900 ML',1,1,'LATA\r\n','32129090',1149,'UC274-0.9',0,218.81,0,'PIGMTO'),(105,16,'CONC. UNIVERSAL ROSA-PIGMENTO 900 ML',1,1,'LATA\r\n','32129090',1150,'UC275-0.9',0,100.91,0,'PIGMTO'),(106,16,'CONC. UNIVERSAL MARROM TRANSP.-PIGMENTO 900 ML',1,1,'LATA\r\n','32129090',1151,'UC276-0.9',0,99.84,0,'PIGMTO'),(107,16,'conc. universal azul avermelhado-pigmento 900 ml ',1,1,'LATA\r\n ','32129090',1152,'uc277-0.9 ',0,139.35,0,'PIGMTO'),(108,16,'conc. amarelo esverdeado transp.-pigmento 900 ml',1,1,'LATA\r\n','32129090',1153,'uc278-0.9',0,299.6,0,'PIGMTO'),(109,16,'conc. universal vermelho avioletado-pigmento 900 ml',1,1,'LATA\r\n','32129090',1154,'uc279-0.9',0,102.18,0,'PIGMTO'),(110,16,'conc. universal preto azulado-pigmento 900 ml',4,1,'LATA\r\n','32129090',1155,'uc280-0.9',0,49.67,0,'PIGMTO'),(111,16,'conc. universal branco-pigmento 3.6 ml ',3,1,'GALAO\r\n ','32129090',1156,'uc281-3.6 ',0,216.12,0,'PIGMTO'),(112,16,'conc. universal amarelo ouro-pigmento 900 ml ',3,1,'LATA\r\n ','32129090',1157,'uc282-0.9 ',0,94.68,0,'PIGMTO '),(113,16,'conc. universal amarelo limAo-pigmento 3.6 ml ',1,1,'GALAO\r\n ','32129090',1158,'uc283-3.6 ',0,331.2,0,'PIGMTO'),(114,16,'conc. universal amarelo oxido-pigmento 900 ml',1,1,'LATA\r\n','32129090',1159,'uc284-0.9',0,47.76,0,'PIGMTO'),(115,16,'conc. universal laranja-pigmento 900 ml',1,1,'LATA\r\n','32129090',1160,'uc285-0.9',0,146.9,0,'PIGMTO'),(116,16,'conc. universal vermelho oxido-pigmento 900 ml',1,1,'LATA\r\n','32129090',1161,'uc286-0.9',0,44.03,0,'PIGMTO'),(117,16,'conc. universal azul - pigmento 900 ML',3,1,'LATA\r\n','32129090',1162,'uc287-0.9',0,49.29,0,'PIGMTO'),(118,16,'conc. universal verde-pigmento 900 ml',1,1,'LATA\r\n','32129090',1163,'uc288-0.9',0,53.13,0,'PIGMTO'),(119,16,'conc. universal vermelho pleno-pigmento -900 ml',1,1,'LATA\r\n','31129090',1164,'uc289-0.9',0,48.75,0,'PIGMTO'),(120,16,'conc. universal preto-pigmento 3.6 ml  ',3,1,'GALAO\r\n ','32129090',1165,'uc290-3.6  ',0,203.35,0,'PIGMTO'),(121,16,'conc. universal vermelho limpo-pigmento 900 ml',1,1,'LATA\r\n','32129090',1166,'uc291-0.9',0,65.52,0,'PIGMTO'),(122,16,'conc. universal amarelo transp. pigmento 900 ml',1,1,'LATA\r\n','31129090',1167,'uc294-0.9',0,61.61,0,'PIGMTO'),(123,16,'conc. universal vermelho transp.- pigmento 900 ml',1,1,'LATA\r\n','32129090',1168,'uc296-0.9',0,50.09,0,'PIGMTO'),(124,16,'conc. universal azul esverdeado- pigmento 900 ml',1,1,'LATA\r\n','32129090',1169,'uc297-0.9',0,54.27,0,'PIGMTO'),(125,16,'conc. universal azul escuro-pigmento 900 ml',3,1,'LATA\r\n','32129090',1170,'uc298-0.9',0,87.69,0,'PIGMTO'),(126,16,'conc.fosqueante universal- pigmento 3.6 ml ',1,1,'GALAO\r\n ','32129090',1171,'uc525-3.6 ',0,148.8,0,'PIGMTO'),(127,16,'soluCAo para ajuste metAlico -pigmento 900 ml ',1,1,'LATA\r\n ','32129090',1172,'uc580-0.9 ',0,42.37,0,'PIGMTO'),(128,16,'conc. aluminio medio brilhante-pigmento 900 ml ',1,1,'LATA\r\n ','32129090',1173,'uc643-0.9 ',0,198.34,0,'PIGMTO'),(129,16,'conc. aluminio graudo 900 ml ',1,1,'LATA\r\n ','32129090',1174,'uc645-0.9 ',0,81.61,0,'PIGMTO'),(130,16,'conc. aluminio super fino -pigmento 900 ML ',1,1,'LATA\r\n ','32129090',1175,'uc648-0.9 ',0,96.23,0,'PIGMTO'),(131,16,'conc. aluminio fino-pigmento 900 ml ',1,1,'LATA\r\n ','32129090',1176,'uc650-0.9 ',0,65.67,0,'PIGMTO'),(132,16,'conc. de aluminio medio-pigmento 900 ml ',1,1,'LATA\r\n ','32129090',1177,'uc655-0.9 ',0,69.13,0,'PIGMTO'),(133,16,'conc. aluminio super graudo',1,1,'LATA\r\n','32129090',1178,'uc675-0.9',0,147.17,0,'PIGMTO'),(134,16,'conc. aluminio brilhante -pigmento 900 ml',1,1,'LATA\r\n','32129090',1179,'uc680-0.9',0,102.3,0,'PIGMTO'),(135,16,'conc. aluminio medio limpo-pigmento 900 ml ',1,1,'LATA\r\n ','32129090',1180,'uc685-0.9 ',0,61.18,0,'PIGMTO'),(136,16,'thinner para base poliester 9700- para  pigmento 18 lt  ',1,1,'GALAO\r\n ','38140090',1181,'uc700-018  ',0,239.76,65,'VENDA'),(137,13,'BARRA DE ALUMINIO DE PORTICO (1,80 mt)  ',2,2,'PECA\r\n ','87082999',101,'101 ',0,400,0,'VENDA'),(138,13,'BARRA DE ALUMiNIO PERFIL 7 X16 (735 MM) ',15,10,'PECA\r\n ','87082999',102,'102 ',0,50,0,'VENDA'),(139,13,'BARRA DE PORTICO CENTRAL - 180 -1,60 -1,40 MT',12,6,'PECA\r\n','87082999',103,'103',0,750,0,'VENDA'),(140,13,'CABO DE AcO (3/16) COM CLIPS-11 MTS ',100,200,'PECA\r\n ','87082999',105,'105 ',0,172,0,'VENDA'),(141,13,'CHAO SANF.  ONIBUS COMPl. C/ VARETA   ',21,6,'PAR\r\n ','87082999',107,'107   ',0,920,0,'VENDA '),(142,13,'CURVA DE ALUMINIO (teto OU  chAo)  ',440,50,'PECA\r\n ','87082999',108,'108  ',0,80,0,'VENDA '),(143,13,'ESTICADOR  DE CABO DE AcO   ',14,20,'PECA\r\n ','87082999',110,'110  ',0,57.5,0,'VENDA '),(144,13,'HASTE TELESCOPICA',5,6,'PECA\r\n','87082999',111,'111',0,517,0,'VENDA'),(145,19,'PINO REI    ',13,5,'PEÇA\r\n ','87082999',121,'121    ',0,375,60,'VENDA '),(146,13,'PISO DE BORRACHA',8,5,'PECA\r\n','87082999',122,'122',0,100,0,'VENDA'),(147,13,'CLIPS -PRESILHA CABO DE AcO (3/16)  ',73,200,'PECA\r\n ','87082999',123,'123  ',0,1.2,0,'VENDA '),(148,13,'VARETA DE CHaO DE SANFONA ',200,50,'PECA\r\n ','87082999',127,'127 ',0,80,0,'VENDA'),(149,13,'ZIPER  DA SANFONINHA INTERNA ',48,10,'PECA\r\n','87082999',128,'128',0,200,0,'VENDA'),(150,13,'PERFIL DE BORRACHA PARA SUSPENSAO(9 MT)  ',8,1,'ROLO\r\n ','87082999',129,'129  ',0,160,0,'VENDA'),(151,13,'TERMINAL ESFERICO-cabeÃ§a da Haste',18,20,'PECA\r\n','87082999',139,'139',0,45,0,'VENDA'),(152,13,'CALAFETADOR (bisnaga) - MS 40 ',23,12,'UNID\r\n ','87082999',140,'140 ',0,15,0,'VENDA '),(153,13,'COLA PVC -SANFONA',26,50,'LATA\r\n','87082999',142,'142',0,13.85,0,'VENDA'),(154,13,'CONDUITE PRETO EM ROLOS 100 MTS',3,1,'ROLO\r\n','87082999',143,'143',0,950,0,'VENDA'),(155,13,'CURSOR DE ZIPER',80,30,'PECA\r\n','87082999',144,'144',0,0.6,0,'VENDA'),(156,13,'ESTOPA - 200 GR',93,50,'PACOTE\r\n','87082999',145,'145',0,1.9,0,'VENDA'),(157,13,'FECHO PARA CHAO  DE SANFONA',200,50,'PECA\r\n','87082999',146,'146',0,3,0,'VENDA'),(158,22,'FITA ADESIVA (EMBALAR) ',0,10,'ROLO\r\n ','87282999',147,'147 ',0,4,0,'VENDA'),(159,29,'GRAMPO 73/8  ',2,2,'CAIXA\r\n ','87082999',148,'148 ',0,12,0,'VENDA'),(160,29,'GRAMPO 23/8 ',14,5,'CAIXA\r\n ','87082999',149,'149 ',0,12,0,'VENDA'),(161,29,'GRAMPO 24/8 ',26,5,'CAIXA\r\n ','87082999',150,'150 ',0,12,0,'VENDA'),(162,35,'LINHA BRANCA ',2,1,'ROLO\r\n ','87082999',151,'151 ',0,8,0,'VENDA'),(163,35,'LINHA CINZA ',30,20,'ROLO\r\n ','87082999',152,'152 ',0,8,0,'VENDA'),(164,36,'MOLA PARA HASTE TELESCOPICA ',41,10,'PECA\r\n ','87092999',155,'155 ',0,3,0,'VENDA'),(165,24,'OLEO FINO DE MAQUINA ',19,10,'UNID\r\n ','87082999',157,'157 ',0,1.98,0,'VENDA'),(166,27,'PALHA DE ACO ',187,50,'UNID\r\n ','87082999',158,'158 ',0,0.6,0,'VENDA'),(169,32,'CATALISADOR UNIVERSAL TINTA-900 ML',2,5,'LATA\r\n','32249931',141,'141',0,55.15,0,'VENDA'),(170,38,'REBITE 4.8 X16  ',600,1,'PECA\r\n ','00000000',173,'173  ',0,0.05,0,'VENDA'),(171,16,'PAPEL MARROM DE EMBALAR',6,1,'ROLO\r\n','00000000',160,'160',0,5,65,'VENDA'),(172,38,'PARAFUSO AUTO BROC. 2.5 ',1500,500,'PECA\r\n ','00000000',161,'161 ',0,0.05,0,'VENDA'),(173,38,'PARAFUSO AUTO BROC. 4 CM',50,50,'PECA\r\n','00000000',162,'162',0,0.07,0,'VENDA'),(174,38,'PARAFUSO CHIP CHATO 4.0X16',2600,500,'PECA\r\n','00000000',163,'163',0,0.05,0,'VENDA'),(175,34,'parafuso m10x35',80,20,'PECA\r\n','00000000',164,'164',0,0.05,0,'VENDA'),(176,34,'parafuso m8x20 sextavado',1000,300,'PECA\r\n','00000000',165,'165',0,0.05,0,'VENDA'),(177,16,'parafuso m8x25 sextavado',450,100,'PECA\r\n','00000000',166,'166',0,0.05,65,'VENDA'),(178,34,'PARAFUSO com porca m5x20',765,300,'PECA\r\n','00000000',167,'167',0,0.05,0,'VENDA'),(179,28,'plastico bolha',6,2,'ROLO\r\n','00000000',168,'168',0,35,0,'VENDA'),(180,34,'PORCA M10-ESQUERDA ',20,30,'PECA\r\n ','00000000',170,'170 ',0,3,0,'VENDA'),(181,34,'PORCA M10-DIREITA',396,50,'PECA\r\n','00000000',171,'171',0,0.5,0,'VENDA'),(182,38,'rebite 4.8x35',4000,1000,'PECA\r\n','00000000',172,'172',0,0.04,0,'VENDA'),(183,39,'resina qualipur 450- 18 lt',2,1,'LATA\r\n','00000',175,'175',0,973.05,0,'VENDA'),(184,40,'TECIDO FINO-9000',0,3,'ROLO\r\n','00000',178,'178',0,2000,0,'VENDA'),(185,40,'TECIDO FUNDO PRETO ESP. TOLDO',6,1,'ROLO\r\n','0000000',179,'179',0,2000,0,'VENDA'),(186,40,'TECIDO GROSSO-12000',6,2,'ROLO\r\n','00000',180,'180',0,3000,0,'VENDA'),(187,40,'TECIDO FINO PRETO PARA CHAO',1,1,'ROLO\r\n','00000',181,'181',0,1000,0,'VENDA'),(188,16,'TENSOR BRANCO (ELASTICO)',500,100,'MT\r\n','00000',182,'182',0,8,65,'VENDA'),(189,23,'TINTA PARA CARIMBO 250 ML',2,1,'LATA\r\n','00000',184,'184',0,65,0,'VENDA'),(190,26,'VELCRO CRESPO -MACHO',4,5,'ROLO\r\n','0000',185,'185',0,32,0,'VENDA'),(191,26,'VELCRO LISO-FEMEA',254,10,'ROLO\r\n','000',186,'186',0,5,0,'VENDA'),(192,26,'ziper em metros',100,50,'MT\r\n','0000000',187,'187',0,1.15,0,'VENDA'),(193,23,'anti espumante -sanfona',1,1,'LATA\r\n','0000',188,'188',0,30,0,'VENDA'),(194,26,'argola para sanfoninha',200,50,'PECA\r\n','0000',189,'189',0,0.4,0,'VENDA'),(195,41,'bansis - solvente 200lt',100,100,'PECA\r\n','0000',190,'190',0,1.672,0,'VENDA'),(196,24,'barra de sebo para serra',17,5,'PECA\r\n','00000',191,'191',0,4.5,0,'VENDA'),(197,33,'barra roscada m10',26,10,'PECA\r\n','0000',192,'192',0,8,0,'VENDA'),(201,13,'MANUT. DE SANFONA COM PINTURA COMPLETA   ',99,0,'CONJ.\r\n ','   ',340,'340   ',0,3000,0,'SERVICO'),(202,16,'TAMPA DOSADORA PARA GALAO 3.6 ML',12,12,'LATA\r\n','84799090',1183,'000.400',0,42.31,65,'VENDA'),(203,16,'TAMPA DOSADORA P LATA PIG. 900 ML',56,56,'LATA\r\n','84799090',1182,'000.401',0,31.99,65,'VENDA'),(215,16,'ENDURECEDOR p/ verniz  P/ PU-150 ML ',10,12,'LATA\r\n ','38249931',1187,'573.008-0.15 ',0,5.88,50,'VENDA '),(214,16,'VERNIZ PU BICOMPONENTE- 750 ML',10,12,'LATA\r\n','32081020',1186,'543.800-0.75',0,10.25,50,'VENDA'),(212,13,'SANFONA REMANUFATURADA A BASE DE TROCA (instalada) ',100,50,'CONJ.\r\n ','87082999',325,'325 ',0,9500,0,'SERVICO'),(213,16,'massa poliester com fibra- 750 gr',11,12,'LATA\r\n','32149000',1185,'508.800-0.75',0,21.16,40,'VENDA'),(211,13,'SANFONA ELEVADA A BASE DE TROCA (instalada) ',100,5,'CONJ.\r\n ','87082999',309,'309 ',0,3000,0,'SERVICO'),(204,16,'esm.pu ac- braNCO carretel. mineracao   ',99,0,'LATA\r\n ','32081010',7003,'0009         ',0,36.85,65,'TINTA '),(205,16,'THINNER 5000 -TAMBOR DE 200 LT',0,0,'UNID\r\n','',1184,'',0,1067,30,'VENDA'),(210,16,'LACA NC CINZA GRADE CONSTATION MINER. P/F19 ',99,0,'LATA\r\n ','32081010',7002,'0016 ',0,38.44,80,'TINTA '),(206,16,'pu-ac preto caterp. semi brilho mine.p/f19    ',96,0,'LATA\r\n ','32081010',7004,'0012          ',0,30.55,65,'TINTA '),(207,16,'pu-ac amaR. komatsu miner. p/f19  ',99,0,'LATA\r\n ','32081010',7005,'0013       ',0,38.36,90,'TINTA '),(220,16,'ESM-PU/AC AMARELO CANARIO VW MINERAÃ‡ÃƒO     ',96,0,'LATA\r\n ','32081010',7006,'APA0018     ',0,34,85,'TINTA '),(208,16,'pu-ac azul jacarei 2017 ao 2177-01122372 p/f19 ',99,0,'LATA\r\n ','32081010',7000,'0014   ',0,36.5,70,'TINTA '),(209,16,'pu-ac branco escolar ant.jacarei -01123020 p/f19 ',93,0,'LATA\r\n ','32081010',7001,'0015   ',0,30.05,70,'TINTA '),(216,16,'CONC.UNIVERSAL AMARELO OURO- 900 ML',4,4,'LATA\r\n','32129090',1188,'UC282-0.9',0,94.67,0,'PIGMTO'),(217,16,'CONC.UNIVERSAL branco - 900 ML',2,2,'LATA\r\n','32129090',1189,'uc281-0.9',0,56.34,0,'PIGMTO'),(218,15,'ADESIVO PLASTICO ULTRA LIGHT -LATA 2,5 KG       ',8,1,'LATA\r\n ','32141010',1190,'1MG015       ',0,40.16,38,'VENDA '),(219,25,'estilete largo western',1,2,'PECA\r\n','82119390',1191,'1191',0,3.5,60,'VENDA'),(221,16,'LACA NC CINZA VW PARACHOQUE MINERAÃ‡ÃƒO         ',97,0,'LATA\r\n ','32081010',7007,'ANC0019BR      ',0,35.15,83,'TINTA '),(225,16,'PU-AC BRANCO MICRO-VARIAÃ‡Ã•ES 01123019-jacareÃ­ p/f19   ',74,0,'LATA\r\n ','32081010',7008,'APA0023   ',0,31.27,70,'TINTA '),(227,15,'ADESIVO PLASTICO ULTRA LIGHT -495 g ',48,20,'LATA\r\n ','35061090',1192,'1mg024 ',0,9.1,40,'VENDA '),(228,15,'massa anti-ruido 1,3 kg ',12,20,'LATA\r\n ','27150000',1193,'3mg035 ',0,8.89,40,'VENDA '),(229,15,'batida de pedra 1/4 ',12,10,'LATA\r\n ','32091010',1194,'4ma031 ',0,9.5,40,'VENDA '),(230,15,'veda-choque 290 g cj',6,10,'LATA\r\n','35069190',1195,'4mp020',0,56.53,40,'VENDA'),(231,15,'massa calafetar cinza-350 gr',15,10,'LATA\r\n','32141010',1196,'ca245',0,6.22,40,'VENDA'),(232,15,'massa de calafetar preta-350 gr',13,10,'LATA\r\n','32141010',1197,'ca246',0,6.22,40,'VENDA'),(234,25,'fita dupla face ',0,1,'UNID\r\n ','59061010',1198,'1198 ',0,24.9,20,'VENDA '),(236,16,'pu ac azul jacarei 01123024 p/f 19 ',97,0,'LATA\r\n ','32081010',7009,'apa0020 ',0,30.57,70,'TINTA '),(235,23,'spray sintetico preto -maza 250 gr',0,1,'LATA\r\n','32082019',1199,'1199',0,15.9,20,'VENDA'),(237,16,'base poliester amarelo canario vw mineraÃ§Ã£o p/f19 ',99,0,'LATA','32081010',7010,'ape0024',0,26.23,90,'TINTA'),(238,16,'laca viaÃ§Ã£o jacarei 01122213 ',99,0,'LATA\r\n ','32081010',7011,'anc0033br ',0,41.57,70,'TINTA '),(239,16,'laca cinza escuro painel 01122391 p/f19 ',99,0,'LATA\r\n ','32081010',7012,'anc0032br ',0,40.4,70,'TINTA ');
/*!40000 ALTER TABLE `tb_produto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_usuario`
--

DROP TABLE IF EXISTS `tb_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(12) NOT NULL,
  `pass` varchar(12) NOT NULL,
  `class` int(11) DEFAULT NULL,
  `nome` varchar(40) DEFAULT NULL,
  `email` varchar(70) DEFAULT NULL,
  `cel` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_usuario`
--

LOCK TABLES `tb_usuario` WRITE;
/*!40000 ALTER TABLE `tb_usuario` DISABLE KEYS */;
INSERT INTO `tb_usuario` VALUES (1,'tales','spider ',10,'Tales Cembraneli Dantas ','tales@flexibus.com.br               ','(12)99711-3793'),(10,'bruno','bruno',2,NULL,NULL,NULL),(9,'tania','123456',4,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tb_usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-29 19:40:37
